.model small 

.data
msg1 db "Enter a number: ","$" 
msg2 db 10,13,"Number is even","$"
msg3 db 10,13,"Number is odd","$"

.code
mov ax,@data
mov ds,ax
mov dx, offset msg1
mov ah,09h
int 21h           

mov ah,1
int 21h

sub al,48
mov bl,al

div bl

cmp ah,0
JE label: 

mov dx,offset msg3
mov ah,09h 
int 21h 
jmp exit

label:
mov dx,offset msg2
mov ah,09h
int 21h 
exit:

mov ah,4ch
int 21h
