.model small

.data
msg1 db "Enter a number (0-100): $"
msg2 db 10,13,"A$"
msg3 db 10,13,"B$"
msg4 db 10,13,"C$"
msg5 db 10,13,"F$"
msg6 db 10,13,"NOT VALID$"
marks db ?

.code

mov ax,@data
mov ds,ax

mov dx,offset msg1
mov ah,09h
int 21h

mov ah,01h
int 21h
sub al,30h
mov bl,10
mul bl
mov marks,al

mov ah,01h
int 21h
sub al,30h
add marks,al

cmp marks,100
jg INVALID

cmp marks,90
jge A

cmp marks,80
jge B

cmp marks,50
jge C

cmp marks,0
jge F

INVALID:
mov dx,offset msg6
mov ah,09h
int 21h
jmp END

A:
mov dx,offset msg2
mov ah,09h
int 21h
jmp END

B:
mov dx,offset msg3
mov ah,09h
int 21h
jmp END

C:
mov dx,offset msg4
mov ah,09h
int 21h
jmp END

F:
mov dx,offset msg5
mov ah,09h
int 21h

end:
mov ah,4ch
int 21h
