.model small
.data
msg db "Enter 10 numbers: ","$" 
newline db 10,13,"$"  
msg1 db 10,13,"Highest  Number: ","$"
.code  
mov ax,@data
mov ds,ax
mov dx,offset msg
mov ah,09h
int 21h  
mov dl,'0'
mov cx,10
L1:
mov dx,offset newline
mov ah,09h           
int 21h
mov ah,01h
int 21h   
cmp al,bl
JG swap
jmp skip
swap:
xchg al,bl
skip:
loop L1
mov dx,offset msg1
mov ah,09h
int 21h
mov dl,bl
mov ah,02h
int 21h
mov ah,4ch
int 21h