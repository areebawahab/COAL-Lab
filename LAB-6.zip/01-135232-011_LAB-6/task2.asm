.org 100h
.code
mov cx,9
l1:
mov ax,cx
mov bl,2
mov ah,0
div bl
cmp ah,0
JE exit
mov dx,cx
add dx,48
mov ah,2
int 21h
exit:
loop l1

mov ah,4ch
int 21h